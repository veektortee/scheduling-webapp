#!/usr/bin/env python3
"""
scheduler_sat_core.py - Real scheduler_sat.py implementation from testcase_gui.py
Complete advanced medical scheduling with sophisticated constraint system
"""

import time
import json
from ortools.sat.python import cp_model
from typing import Dict, List, Any, Tuple
from collections import defaultdict, Counter
from datetime import datetime, date
import math

# Default constants matching testcase_gui.py exactly
DEFAULT_CONSTANTS = {
    "solver": {
        "max_time_in_seconds": 1000,
        "phase1_fraction": 0.4,
        "relative_gap": 0.00001,
        "num_threads": 8,
        "min_total_is_hard": False
    },
    "weights": {
        "hard": {
            "uncovered_shift": 0.0,
            "slack_unfilled": 20,
            "slack_shift_less": 1,
            "slack_shift_more": 1,
            "slack_cant_work": 20,
            "slack_consec": 1,
            "rest_12h": 0.0,
            "type_range": 0.0,
            "weekend_range": 0.0,
            "total_limit": 0.0,
            "consecutive": 0.0
        },
        "soft": {
            "weekday_pref": 1.0,
            "type_pref": 1.0,
            "cluster": 10000,
            "cluster_size": 1,
            "cluster_any_start": 0.0,
            "cluster_weekend_start": 0.0,
            "requested_off": 10000000,
            "days_wanted_not_met": 10000000,
            "transitions_any": 0.0,
            "transitions_night": 0.0,
            "unfair_number": 5000
        }
    },
    "objective": {"hard": 1, "soft": 1, "fair": 0}
}

def safe_get(d, *keys, default=None):
    """Safe nested dictionary access"""
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur

def get_num(d, *keys, default=0.0):
    """Extract numeric value with fallback"""
    v = safe_get(d, *keys, default=None)
    try:
        return float(v) if v is not None else default
    except (TypeError, ValueError):
        return default

def norm_name(name: str) -> str:
    """Normalize name for matching"""
    return ''.join(c for c in (name or '').lower() if c.isalnum())

def infer_allowed_types(shift: Dict[str,Any], provider_types: List[str]) -> set:
    """Infer allowed provider types for a shift"""
    allowed = shift.get('allowed_provider_types')
    if allowed:
        return set(allowed)
    stype = shift.get('type', '')
    if isinstance(stype, str) and '_' in stype:
        prefix = stype.split('_')[0]
        if prefix in provider_types:
            return {prefix}
    return set(provider_types)

def iso_weekday_name(date_str: str) -> str:
    """Get weekday name from ISO date string"""
    try:
        y, m, d = map(int, date_str.split('-'))
        return date(y, m, d).strftime('%A')
    except:
        return ""

# ...existing code...
