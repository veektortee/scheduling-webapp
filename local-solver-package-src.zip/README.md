Local solver package source

This folder contains a minimal source layout for the local solver package.
To install locally (from this folder):

    python -m pip install .

Or to build a zip source distribution:

    python -m pip wheel --no-deps -w dist .

The package attempts to import the repository-level `testcase_gui.py` if present.
