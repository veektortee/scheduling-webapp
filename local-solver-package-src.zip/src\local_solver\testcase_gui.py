"""Wrapper module that delegates to the repo-level `testcase_gui.py` when available.

This keeps the package small while exposing the same module name when installed
from this project. At runtime it attempts to locate the repository's top-level
`testcase_gui.py` and import it. If not found, it exposes a minimal fallback.
"""
import importlib.util
import sys
from pathlib import Path

def _load_repo_testcase_gui():
	# Look for testcase_gui.py two levels up from this file (project root)
	here = Path(__file__).resolve()
	candidate = here.parents[3] / "scheduling-webapp" / "testcase_gui.py"
	if candidate.exists():
		spec = importlib.util.spec_from_file_location("testcase_gui", str(candidate))
		module = importlib.util.module_from_spec(spec)
		spec.loader.exec_module(module)
		return module
	# fallback: try common locations
	candidate2 = Path("c:/Werk/Webapp/testcase_gui.py")
	if candidate2.exists():
		spec = importlib.util.spec_from_file_location("testcase_gui", str(candidate2))
		module = importlib.util.module_from_spec(spec)
		spec.loader.exec_module(module)
		return module
	return None

_repo_mod = _load_repo_testcase_gui()
if _repo_mod is not None:
	# Inject names into this module's namespace
	globals().update({k: getattr(_repo_mod, k) for k in dir(_repo_mod) if not k.startswith("__")})
else:
	# Minimal fallback stub
	def Solve_test_case(path):
		raise RuntimeError("testcase_gui not found in repository; please run from the project root or install the full package.")

__all__ = ["Solve_test_case"]
